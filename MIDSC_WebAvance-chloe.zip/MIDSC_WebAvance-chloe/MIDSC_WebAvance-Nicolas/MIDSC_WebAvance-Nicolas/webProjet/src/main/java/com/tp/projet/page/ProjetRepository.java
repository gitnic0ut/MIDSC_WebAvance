package com.tp.projet.page;

import org.springframework.data.repository.CrudRepository;

/**
 * ProjetRepository
 */
public interface ProjetRepository extends CrudRepository<Projet, Long>{

	    
}