package com.tp.projet.page;

import org.springframework.data.repository.CrudRepository;

/**
 * PlanningRepository
 */
public interface PlanningRepository extends CrudRepository<Planning, Long>{

    
}