package com.tp.projet.page;

import org.springframework.data.repository.CrudRepository;

/**
 * MessagerieRepository
 */
public interface MessagerieRepository extends CrudRepository<Messagerie, Long>{

    
}