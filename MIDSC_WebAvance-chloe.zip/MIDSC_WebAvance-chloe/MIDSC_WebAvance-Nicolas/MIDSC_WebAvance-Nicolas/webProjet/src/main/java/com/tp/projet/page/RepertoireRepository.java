package com.tp.projet.page;

import org.springframework.data.repository.CrudRepository;

/**
 * RepertoireRepository
 */
public interface RepertoireRepository extends CrudRepository<Repertoire, Long>{

    
}