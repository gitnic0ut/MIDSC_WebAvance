package com.tp.projet.utilisateur;

import org.springframework.data.repository.CrudRepository;

/**
 * UtilisateurRepository
 */
public interface UtilisateurRepository extends CrudRepository<Utilisateur, Long> {
 
    

}