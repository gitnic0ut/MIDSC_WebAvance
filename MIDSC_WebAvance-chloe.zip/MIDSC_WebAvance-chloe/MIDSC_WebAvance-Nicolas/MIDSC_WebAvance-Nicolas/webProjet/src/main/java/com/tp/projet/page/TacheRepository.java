package com.tp.projet.page;

import org.springframework.data.repository.CrudRepository;

/**
 * TacheRepository
 */
public interface TacheRepository extends CrudRepository<Tache, Long>{

    
}