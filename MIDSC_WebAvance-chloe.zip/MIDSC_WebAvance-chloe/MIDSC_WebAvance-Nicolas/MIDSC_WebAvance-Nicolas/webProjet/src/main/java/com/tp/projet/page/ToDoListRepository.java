package com.tp.projet.page;

import org.springframework.data.repository.CrudRepository;

/**
 * ToDoListRepository
 */
public interface ToDoListRepository extends CrudRepository<ToDoList, Long>{

    
}