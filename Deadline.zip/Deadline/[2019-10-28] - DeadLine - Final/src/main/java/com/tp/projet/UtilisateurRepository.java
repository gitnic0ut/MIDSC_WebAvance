package com.tp.projet;

import org.springframework.data.repository.CrudRepository;

/**
 * UtilisateurRepository
 */
public interface UtilisateurRepository extends CrudRepository<Utilisateur, Long> {
 
}