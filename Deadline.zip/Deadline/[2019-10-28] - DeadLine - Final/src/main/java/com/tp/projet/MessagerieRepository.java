package com.tp.projet;

import org.springframework.data.repository.CrudRepository;

/**
 * MessagerieRepository
 */
public interface MessagerieRepository extends CrudRepository<Messagerie, Long>{

    
}