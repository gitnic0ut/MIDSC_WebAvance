package com.tp.projet;

import org.springframework.data.repository.CrudRepository;

/**
 * TacheRepository
 */
public interface TacheRepository extends CrudRepository<Tache, Long>{

    
}