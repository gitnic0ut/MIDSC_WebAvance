package com.tp.projet;

import org.springframework.data.repository.CrudRepository;

/**
 * ProjetRepository
 */
public interface ProjetRepository extends CrudRepository<Projet, Long>{

    
}