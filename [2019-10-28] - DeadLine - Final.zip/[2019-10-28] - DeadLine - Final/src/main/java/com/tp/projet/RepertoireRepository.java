package com.tp.projet;

import org.springframework.data.repository.CrudRepository;

/**
 * RepertoireRepository
 */
public interface RepertoireRepository extends CrudRepository<Repertoire, Long>{

    
}